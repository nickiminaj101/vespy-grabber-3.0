<img align="center" src='https://cdn.discordapp.com/attachments/1037900641164611659/1059001198184779886/pure-black-background-f82588d3.png'>

# ===== Python Open Source Stub Builder =====

<img align="center" src='https://cdn.discordapp.com/attachments/1037900641164611659/1059001627756998727/python_EvlOkHBWaD.png'>

<h2>Vespy Grabber 2.0</h2>

<h3>Disclaimer</h3>

    THIS SOFTWARE WAS MADE FOR RESEARCH AND EDUCATIONAL PURPOSES ONLY. THE CREATOR OF VESPY GRABBER IS NOT REPONSIBLE OF THE USAGE OF THIS SOFTWARE. IF THIS PROJECT GETS TO MANY COMPLAINS, THIS REPOSITORY WILL BE DELETED.

<h3>Description</h3>

Vespy Logger but better fr. Part of vespy 2.0 project. This is a python open source stub builder that recovers personal information from a windows OS computer, using a tkinter GUI with multiple settings to compile your stub.

JOIN OUR DISCORD : https://discord.gg/GGYmKcUDn9

THIS IS ONLY THE FIRST RELEASE, IF YOU FIND ANY BUGS DM vesper#0003 ON DISCORD

<h3>NEXT UPDATE</h3>

- Fixing Roblox Recovery (Not efficient enough)

- Multi tool

- Options, such as music player, hide console, etc

- More features

<h3>How To Use</h3>

You basically need a brain and python knowledge, this is the first step

Download python 3.9.5 and + (not python 3.11+)

Make sure to install pip while downloading python (in python setup)

Install requirements using install.bat

Setup your stub, webhook and compile

You can also modify the code in utils/

<h3>Credits</h3>

Credits to scel#7166

vesper#0003 / @i_might_be_vesper

